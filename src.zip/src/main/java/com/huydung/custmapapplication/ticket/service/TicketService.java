package com.huydung.custmapapplication.ticket.service;

import com.huydung.custmapapplication.common.dto.AbstractDTO;
import com.huydung.custmapapplication.ticket.dto.BulkActionResultDTO;
import com.huydung.custmapapplication.ticket.dto.BulkTicketActionRequest;
import com.huydung.custmapapplication.ticket.dto.TicketImportResultDTO;
import com.huydung.custmapapplication.ticket.dto.TicketResponseDTO;
import com.huydung.custmapapplication.ticket.dto.TicketTypeInfoDTO;
import com.huydung.custmapapplication.ticket.dto.TicketSearchCriteria;
import com.huydung.custmapapplication.ticket.dto.UpdateTicketActionRequest;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

public interface TicketService {

    // confirmArchive = true: đồng ý lưu trữ nhiều ca cùng lúc khi file import không còn chứa các ca đó
    TicketImportResultDTO importExcelFile(MultipartFile file, boolean confirmArchive);

    // Danh sách ca đang mở, có phân trang (page bắt đầu từ 1)
    AbstractDTO<TicketResponseDTO> getTicketsForCurrentUser(TicketSearchCriteria criteria);

    // Danh sách ca ĐÃ HẸN (Hẹn giờ / Hẹn khác), xếp theo giờ hẹn gần nhất, có phân trang
    AbstractDTO<TicketResponseDTO> getAppointmentsForCurrentUser(TicketSearchCriteria criteria);

    // Số khách đã hẹn của người đang đăng nhập (hiện trên tab "Đã hẹn" ở thanh dưới); cách tính giống trang Khách đã hẹn khi chưa lọc gì
    long countAppointmentsForCurrentUser();

    // tab = COMPLETED (ca đã hoàn thành) | ISSUES (không liên lạc được và vấn đề khác); null = cả hai
    AbstractDTO<TicketResponseDTO> getHistoryForCurrentUser(String staffFilter, String keyword,
                                                            LocalDate fromDate, LocalDate toDate,
                                                            String tab,
                                                            Integer page, Integer size);

    TicketResponseDTO updateTicketAction(Long ticketId, UpdateTicketActionRequest request);

    // Thao tác hàng loạt (chỉ ADMIN): chuyển Đã xử lý hoặc xóa vĩnh viễn các ca được chọn
    BulkActionResultDTO bulkAction(BulkTicketActionRequest request);

    // Đưa ca từ Lịch sử về danh sách chính
    TicketResponseDTO restoreTicket(Long ticketId);

    // Danh sách loại ca kèm số ca đang mở theo phạm vi nhân viên (dựng tab / bộ lọc loại trên giao diện)
    List<TicketTypeInfoDTO> getTicketTypeSummary(String staffFilter);

    List<String> getAssignedStaffList();

    List<String> getAreaListForStaff(String staffName);

    List<String> getCabinetPrefixList(String staffName, String area);

    TicketResponseDTO getTicketDetail(Long ticketId);
}
