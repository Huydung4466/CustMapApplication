/*
 * profile.js - Trang Cá nhân.
 *  - Mọi vai trò: xem thông tin tài khoản, sửa số điện thoại, đổi mật khẩu, đăng xuất, import file KMZ.
 *  - ROLE_ADMIN: thêm import file Excel (phản ánh / hạ tầng).
 *  - ROLE_ADMIN: thêm khu "Quản lý tài khoản" (xem tài khoản khác, tạo tài khoản nhân viên, đặt lại mật khẩu nhân viên).
 * Cần: CTX, app-common.js, Bootstrap.
 */
let me = null;
let isAdmin = false;
let isCamera = false;       // tài khoản đang đăng nhập có quyền Camera (ROLE_CAMERA)
let searchTimer = null;
let createModal = null;
let resetModal = null;
let resetTarget = null;

const ROLE_LABELS = { ROLE_ADMIN: 'Quản trị viên', ROLE_STAFF: 'Nhân viên', ROLE_CAMERA: 'Camera' };
const ROLE_CLASSES = { ROLE_ADMIN: 'role-admin', ROLE_STAFF: 'role-staff', ROLE_CAMERA: 'role-camera' };

document.addEventListener('DOMContentLoaded', async function () {
    createModal = new bootstrap.Modal(document.getElementById('createModal'));
    resetModal = new bootstrap.Modal(document.getElementById('resetModal'));
    await loadProfile();
    applyImportPermissions();
    if (isAdmin) {
        document.getElementById('adminSection').classList.remove('d-none');
        document.getElementById('cameraSection').classList.remove('d-none');
        loadUsers();
        loadCameraSettings();
    }
    // Tài khoản có quyền Camera: hiện phần bật / tắt tự xóa ảnh
    if (isCamera) {
        document.getElementById('photoSection').classList.remove('d-none');
        loadPhotoSettings();
    }
});

function roleBadges(roles) {
    return (roles || []).map(function (r) {
        const cls = ROLE_CLASSES[r] || 'role-staff';
        return '<span class="role-badge ' + cls + '">' + escapeHtml(ROLE_LABELS[r] || r) + '</span>';
    }).join(' ');
}

// ===================== THÔNG TIN CỦA TÔI =====================
async function loadProfile() {
    try {
        const auth = await AppNav.getMe();   // thanh trên cùng (top-navbar) đã lấy sẵn
        isAdmin = !!auth.admin;
        isCamera = !!auth.camera;
        me = await apiFetch(CTX + '/api/profile');
        document.getElementById('avatar').textContent = initialsOf(me.fullName);
        document.getElementById('pFullName').textContent = me.fullName;
        document.getElementById('pUsername').textContent = '@' + me.username;
        document.getElementById('pRoles').innerHTML = roleBadges(me.roles);
        document.getElementById('pStatus').innerHTML = me.status === 1
            ? '<span class="text-success fw-semibold"><i class="fa-solid fa-circle-check me-1"></i>Đang hoạt động</span>'
            : '<span class="text-danger fw-semibold"><i class="fa-solid fa-lock me-1"></i>Đã khóa</span>';
        document.getElementById('phoneInput').value = me.phone || '';
    } catch (e) {
        showToast(e.message, true);
    }
}

async function savePhone() {
    const btn = document.getElementById('btnSavePhone');
    btn.disabled = true;
    try {
        me = await apiFetch(CTX + '/api/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: document.getElementById('phoneInput').value })
        });
        document.getElementById('phoneInput').value = me.phone || '';
        showToast('Đã lưu số điện thoại');
    } catch (e) {
        showToast(e.message, true);
    } finally {
        btn.disabled = false;
    }
}

// ===================== NẠP DỮ LIỆU (IMPORT) =====================
let importing = false;

// Chỉ ADMIN thấy ô import Excel; nhân viên chỉ có ô KMZ (full chiều ngang)
function applyImportPermissions() {
    const excelCol = document.getElementById('excelImportCol');
    const kmzCol = document.getElementById('kmzImportCol');
    if (isAdmin) {
        excelCol.classList.remove('d-none');
    } else {
        kmzCol.classList.replace('col-md-6', 'col-md-12');
    }
}

// Bật/tắt trạng thái "đang import": khóa ô chọn file + nút, nút đang chạy hiện vòng xoay, hiện thanh chạy
function setImporting(on, btn, busyText) {
    importing = on;
    ['excelFileInput', 'kmzFileInput', 'btnUploadExcel', 'btnUploadKmz'].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.disabled = on;
    });
    document.getElementById('importBusy').classList.toggle('d-none', !on);
    if (on) document.getElementById('importBusyText').textContent = busyText || 'Đang tải lên và xử lý, vui lòng không đóng trang...';
    if (btn) {
        if (on) {
            btn.dataset.html = btn.innerHTML;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>Đang import...';
        } else if (btn.dataset.html) {
            btn.innerHTML = btn.dataset.html;
            delete btn.dataset.html;
        }
    }
}

// Đang import mà đóng/chuyển trang thì hỏi lại, tránh làm gián đoạn
window.addEventListener('beforeunload', function (e) {
    if (importing) { e.preventDefault(); e.returnValue = ''; }
});

function showImportResult(type, message) {
    document.getElementById('importResultAlert').innerHTML =
        '<div class="alert alert-' + type + ' py-1 small mb-0">' + escapeHtml(message) + '</div>';
}

async function uploadExcelFile(confirmArchive) {
    if (importing) return;
    const input = document.getElementById('excelFileInput');
    const file = input.files[0];
    if (!file) { showToast('Hãy chọn file Excel trước', true); return; }
    const fd = new FormData();
    fd.append('file', file);
    if (confirmArchive === true) fd.append('confirmArchive', 'true');
    const btn = document.getElementById('btnUploadExcel');
    document.getElementById('importResultAlert').innerHTML = '';
    setImporting(true, btn, 'Đang import file Excel, việc này có thể mất vài chục giây...');
    let retry = false;
    try {
        const d = await apiFetch(CTX + '/api/tickets/import', { method: 'POST', body: fd });
        showImportResult('success', d.message);
        input.value = '';
    } catch (e) {
        // Server báo file sắp chuyển rất nhiều ca sang Lịch sử: hỏi lại trước khi làm thật
        if (e.status === 409 && e.data && e.data.code === 'CONFIRM_ARCHIVE') {
            setImporting(false, btn);
            if (confirm(e.message + '\n\nBấm OK để vẫn import và chuyển các ca này sang Lịch sử.')) {
                retry = true;
            } else {
                showImportResult('warning', 'Đã hủy import, dữ liệu không thay đổi.');
            }
        } else {
            showImportResult('danger', e.message);
        }
    } finally {
        setImporting(false, btn);
    }
    if (retry) await uploadExcelFile(true);
}

async function uploadKmzFile() {
    if (importing) return;
    const input = document.getElementById('kmzFileInput');
    const file = input.files[0];
    if (!file) { showToast('Hãy chọn file KMZ/KML trước', true); return; }
    const fd = new FormData();
    fd.append('file', file);
    const btn = document.getElementById('btnUploadKmz');
    document.getElementById('importResultAlert').innerHTML = '';
    setImporting(true, btn, 'Đang import tọa độ tủ, vui lòng chờ...');
    try {
        const d = await apiFetch(CTX + '/api/kmz/import', { method: 'POST', body: fd });
        showImportResult('primary', d.message);
        input.value = '';
        if (window.AppNav) AppNav.refreshKmzCount();
    } catch (e) {
        showImportResult('danger', e.message);
    } finally {
        setImporting(false, btn);
    }
}

// ===================== QUẢN LÝ TÀI KHOẢN (ADMIN) =====================
// Chỉ đặt lại mật khẩu được cho tài khoản nhân viên (ROLE_STAFF) không phải quản trị viên
function canReset(u) {
    const roles = u.roles || [];
    return roles.indexOf('ROLE_STAFF') !== -1 && roles.indexOf('ROLE_ADMIN') === -1;
}

function debounceLoadUsers() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadUsers, 300);
}

async function loadUsers() {
    const box = document.getElementById('userList');
    const kw = document.getElementById('userKeyword').value.trim();
    try {
        const users = await apiFetch(CTX + '/api/users' + (kw ? '?keyword=' + encodeURIComponent(kw) : ''));
        document.getElementById('userCount').textContent = users.length;
        if (!users.length) {
            box.innerHTML = '<div class="text-center text-muted small py-3">Không có tài khoản phù hợp</div>';
            return;
        }
        box.innerHTML = users.map(userRowHtml).join('');
    } catch (e) {
        box.innerHTML = '<div class="alert alert-danger p-2 small mb-0">' + escapeHtml(e.message) + '</div>';
    }
}

function userRowHtml(u) {
    const id = Number(u.id);
    const phone = u.phone ? '<a href="tel:' + escapeHtml(u.phone) + '" class="text-decoration-none">' + escapeHtml(u.phone) + '</a>' : 'Chưa có SĐT';
    const locked = u.status !== 1 ? ' <span class="badge bg-secondary">Khóa</span>' : '';
    const reset = canReset(u)
        ? '<button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-2" onclick="openReset(' + id + ')" title="Đặt lại mật khẩu">'
          + '<i class="fa-solid fa-key me-1"></i>Đặt lại MK</button>'
        : '';
    // Cấp / thu hồi quyền Camera (lưu, xóa, tải ảnh hiện trường); có hiệu lực từ lần đăng nhập kế tiếp của tài khoản đó
    const hasCam = (u.roles || []).indexOf('ROLE_CAMERA') !== -1;
    const cam = '<button type="button" class="btn btn-sm ' + (hasCam ? 'btn-outline-danger' : 'btn-outline-primary') + ' rounded-pill px-2" '
        + 'onclick="toggleCameraRole(' + id + ', ' + (!hasCam) + ')" title="' + (hasCam ? 'Thu hồi quyền Camera' : 'Cấp quyền Camera') + '">'
        + '<i class="fa-solid fa-camera me-1"></i>' + (hasCam ? 'Thu hồi Camera' : 'Cấp Camera') + '</button>';
    return '<div class="user-row">'
        + '<div class="avatar-circle avatar-sm">' + escapeHtml(initialsOf(u.fullName)) + '</div>'
        + '<div class="info"><div class="name">' + escapeHtml(u.fullName) + locked + '</div>'
        +   '<div class="sub">@' + escapeHtml(u.username) + ' • ' + phone + '</div>'
        +   '<div class="mt-1">' + roleBadges(u.roles) + '</div></div>'
        + '<div class="d-flex flex-column gap-1 align-items-stretch">' + cam + reset + '</div>'
        + '</div>';
}

// Mật khẩu ngẫu nhiên 10 ký tự, có cả chữ và số (bỏ các ký tự dễ nhầm như 0/O, 1/l/I)
function generatePassword() {
    const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    const digits = '23456789';
    const all = letters + digits;
    const buf = new Uint32Array(10);
    crypto.getRandomValues(buf);
    const chars = Array.prototype.map.call(buf, function (n) { return all.charAt(n % all.length); });
    chars[0] = letters.charAt(buf[0] % letters.length);
    chars[1] = digits.charAt(buf[1] % digits.length);
    // Xáo trộn để chữ/số không luôn nằm ở đầu
    for (let i = chars.length - 1; i > 0; i--) {
        const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
        const t = chars[i]; chars[i] = chars[j]; chars[j] = t;
    }
    return chars.join('');
}

function passwordProblem(pw, username) {
    if (!pw || pw.length < 8) return 'Mật khẩu phải có ít nhất 8 ký tự';
    if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Mật khẩu phải gồm cả chữ và số';
    if (username && pw.toLowerCase() === username.trim().toLowerCase()) return 'Mật khẩu không được trùng với tên đăng nhập';
    return null;
}

// ----- Tạo tài khoản nhân viên -----
function openCreate() {
    ['cUsername', 'cFullName', 'cPhone'].forEach(function (id) { document.getElementById(id).value = ''; });
    document.getElementById('cPassword').value = generatePassword();
    document.getElementById('createError').textContent = '';
    createModal.show();
}

function fillCreatePassword() {
    document.getElementById('cPassword').value = generatePassword();
}

async function submitCreate() {
    const err = document.getElementById('createError');
    err.textContent = '';
    const username = document.getElementById('cUsername').value.trim();
    const fullName = document.getElementById('cFullName').value.trim();
    const phone = document.getElementById('cPhone').value.trim();
    const password = document.getElementById('cPassword').value;
    if (!username) { err.textContent = 'Nhập tên đăng nhập'; return; }
    if (!fullName) { err.textContent = 'Nhập họ tên (phải trùng tên ở cột "Giao nhân viên" trong file Excel)'; return; }
    const problem = passwordProblem(password, username);
    if (problem) { err.textContent = problem; return; }

    const btn = document.getElementById('btnCreate');
    btn.disabled = true;
    try {
        await apiFetch(CTX + '/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username, fullName: fullName, phone: phone, password: password, roleCodes: ['ROLE_STAFF'] })
        });
        createModal.hide();
        showToast('Đã tạo tài khoản ' + username + '. Hãy gửi mật khẩu cho nhân viên.');
        loadUsers();
    } catch (e) {
        err.textContent = e.message;
    } finally {
        btn.disabled = false;
    }
}

// ----- Đặt lại mật khẩu nhân viên -----
async function openReset(id) {
    // Lấy lại thông tin từ danh sách đang hiển thị
    try {
        const users = await apiFetch(CTX + '/api/users');
        resetTarget = users.filter(function (u) { return Number(u.id) === id; })[0] || null;
    } catch (e) { showToast(e.message, true); return; }
    if (!resetTarget || !canReset(resetTarget)) { showToast('Chỉ đặt lại được mật khẩu của tài khoản nhân viên', true); return; }
    document.getElementById('resetWho').textContent = resetTarget.fullName + ' (@' + resetTarget.username + ')';
    document.getElementById('rPassword').value = generatePassword();
    document.getElementById('resetError').textContent = '';
    resetModal.show();
}

function fillResetPassword() {
    document.getElementById('rPassword').value = generatePassword();
}

async function submitReset() {
    const err = document.getElementById('resetError');
    err.textContent = '';
    if (!resetTarget) return;
    const password = document.getElementById('rPassword').value;
    const problem = passwordProblem(password, resetTarget.username);
    if (problem) { err.textContent = problem; return; }

    const btn = document.getElementById('btnReset');
    btn.disabled = true;
    try {
        await apiFetch(CTX + '/api/users/' + resetTarget.id + '/reset-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ newPassword: password })
        });
        resetModal.hide();
        showToast('Đã đặt lại mật khẩu. Nhân viên sẽ phải đổi mật khẩu khi đăng nhập.');
    } catch (e) {
        err.textContent = e.message;
    } finally {
        btn.disabled = false;
    }
}

// ===================== CẤU HÌNH CAMERA (ADMIN) =====================
// Thứ tự khớp với thứ tự in trên ảnh (camera-capture.js > buildLines)
const CAMERA_OPTIONS = [
    { key: 'showTime',         label: 'Ngày giờ chụp',          sample: '19/10/26 09:43' },
    { key: 'showCoordinates',  label: 'Tọa độ GPS',             sample: "N 12\u00B0 40' 0\", E 108\u00B0 2' 18\"" },
    { key: 'showAddress',      label: 'Địa chỉ',                sample: '12 Lê Duẩn, Tân Lợi, Buôn Ma Thuột, Đắk Lắk' },
    { key: 'showCustomerName', label: 'Tên khách hàng',         sample: 'Nguyễn Văn A' },
    { key: 'showAccount',      label: 'Mã thuê bao (account)',  sample: 'd500_gftth_a1' },
    { key: 'showCabinetCode',  label: 'Mã tủ',                  sample: 'Tủ: DLK0412-A' },
    { key: 'showStaff',        label: 'Tên nhân viên chụp',     sample: 'NV: ' + (me ? me.fullName : 'Họ tên') }
];
let cameraCfg = null;

async function loadCameraSettings() {
    try {
        cameraCfg = await apiFetch(CTX + '/api/settings/camera');
        renderCameraSwitches();
    } catch (e) {
        document.getElementById('cameraSwitches').innerHTML =
            '<div class="alert alert-danger p-2 small mb-0">' + escapeHtml(e.message) + '</div>';
    }
}

function renderCameraSwitches() {
    document.getElementById('cameraSwitches').innerHTML = CAMERA_OPTIONS.map(function (o) {
        return '<div class="form-check form-switch d-flex align-items-center justify-content-between ps-0 py-2 border-bottom">'
            + '<label class="form-check-label flex-grow-1" for="sw-' + o.key + '">' + escapeHtml(o.label) + '</label>'
            + '<input class="form-check-input ms-2 mt-0" type="checkbox" role="switch" id="sw-' + o.key + '"'
            + (cameraCfg[o.key] ? ' checked' : '') + ' onchange="toggleCamera(\'' + o.key + '\', this)" style="width:2.6em;height:1.4em;">'
            + '</div>';
    }).join('');
    renderCameraPreview();
}

function renderCameraPreview() {
    const lines = CAMERA_OPTIONS.filter(function (o) { return cameraCfg[o.key]; });
    const box = document.getElementById('cameraPreview');
    box.innerHTML = lines.length
        ? lines.map(function (o) { return '<div>' + escapeHtml(o.sample) + '</div>'; }).join('')
        : '<div class="text-white-50">Đã tắt hết: ảnh sẽ không có chữ.</div>';
}

async function toggleCamera(key, checkbox) {
    const body = {};
    body[key] = checkbox.checked;
    checkbox.disabled = true;
    try {
        cameraCfg = await apiFetch(CTX + '/api/settings/camera', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        renderCameraPreview();
        showToast('Đã lưu cấu hình camera');
    } catch (e) {
        checkbox.checked = !checkbox.checked;   // lưu lỗi thì trả công tắc về như cũ
        showToast(e.message, true);
    } finally {
        checkbox.disabled = false;
    }
}

// ===================== QUYỀN CAMERA (ADMIN cấp / thu hồi cho tài khoản) =====================
async function toggleCameraRole(id, enable) {
    const msg = enable
        ? 'Cấp quyền Camera cho tài khoản này?\nNgười đó sẽ lưu, xóa và tải được ảnh hiện trường.'
        : 'Thu hồi quyền Camera của tài khoản này?';
    if (!confirm(msg)) return;
    try {
        await apiFetch(CTX + '/api/users/' + id + '/camera-role', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: enable })
        });
        showToast((enable ? 'Đã cấp' : 'Đã thu hồi') + ' quyền Camera. Có hiệu lực khi tài khoản đó đăng nhập lại.', false);
        loadUsers();
    } catch (e) {
        showToast(e.message, true);
    }
}

// ===================== TỰ XÓA ẢNH (tài khoản có quyền Camera) =====================
function showPhotoSettings(cfg) {
    document.getElementById('swPhotoAutoDelete').checked = !!cfg.autoDeleteEnabled;
    document.getElementById('photoRetentionHours').textContent = cfg.retentionHours;
    document.getElementById('photoRetentionHours2').textContent = cfg.retentionHours;
    document.getElementById('photoSettingNote').textContent = cfg.autoDeleteEnabled
        ? 'Đang bật: ảnh quá hạn được dọn tự động (kiểm tra khoảng 10 phút một lần).'
        : 'Đang tắt: ảnh được giữ lại, bộ đếm giờ ở trang Ảnh tạm ẩn.';
}

async function loadPhotoSettings() {
    try {
        showPhotoSettings(await apiFetch(CTX + '/api/photos/settings'));
    } catch (e) {
        showToast(e.message, true);
    }
}

async function togglePhotoAutoDelete(checkbox) {
    const enable = checkbox.checked;
    // Bật lại: ảnh đã quá hạn trong lúc tắt sẽ bị xóa ở lần kiểm tra kế tiếp nên hỏi lại cho chắc
    if (enable && !confirm('Bật tự xóa ảnh?\nẢnh đã quá hạn (kể cả những ảnh quá hạn trong lúc tắt) sẽ bị xóa ở lần kiểm tra kế tiếp, không khôi phục được.')) {
        checkbox.checked = false;
        return;
    }
    checkbox.disabled = true;
    try {
        showPhotoSettings(await apiFetch(CTX + '/api/photos/settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ autoDeleteEnabled: enable })
        }));
        showToast(enable ? 'Đã bật tự xóa ảnh' : 'Đã tắt tự xóa ảnh', false);
    } catch (e) {
        checkbox.checked = !enable;   // lưu lỗi thì trả công tắc về như cũ
        showToast(e.message, true);
    } finally {
        checkbox.disabled = false;
    }
}
